package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {
	
	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	public void saveProduct(Product p) {
		em.persist(p);
	}

	@Transactional
	public Product get(int id) {
		return em.find(Product.class, id);
	}

	@Transactional
	public List<Product> getAll() {
		return em.createQuery("from Product").getResultList();
	}

}






