package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Flight;
import com.cg.service.FlightService;
import com.cg.util.InvalidFlightException;

@RestController
public class FlightController {
	@Autowired
	private FlightService service;
	
	@PostMapping(value="/add", consumes="application/json")
	public String addFlight(@RequestBody Flight flight) {
		int no = service.addFlight(flight);
		return "Flight added with No."+no;
	}

	@GetMapping(value="/byno/{no}", produces="application/json")
	public Flight getFlight(@PathVariable int no) throws InvalidFlightException {
		return service.flightByNo(no);
	}
	
	@GetMapping(value="/bycarrier/{car}", produces="application/json")
	public List<Flight> byCarrier(@PathVariable String car) {
		return service.flightByCarrier(car);
	}
	
	@GetMapping(value="/byroute", produces="application/json")
	public List<Flight> byRoute(@RequestParam("src") String source,
			@RequestParam("dst") String destiny) {
		return service.flightByRoute(source, destiny);
	}
}

