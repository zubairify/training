package com.cg.service;

import java.util.List;

import com.cg.entity.Flight;
import com.cg.util.InvalidFlightException;

public interface FlightService {
	int addFlight(Flight flight);
	
	List<Flight> flightByCarrier(String carrier);
	
	List<Flight> flightByRoute(String source, String destiny);
	
	Flight flightByNo(int no) throws InvalidFlightException;
	
	void removeFlight(int no) throws InvalidFlightException;
	
	void updateFlight(Flight flight);
	
	List<Flight> allFlights();
}
