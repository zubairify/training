package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Flight;
import com.cg.repo.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	private FlightRepository repo;
	
	@Override
	public int addFlight(Flight flight) {
		repo.save(flight);
		return flight.getFlightNo();
	}

	@Override
	public List<Flight> flightByCarrier(String carrier) {
		return repo.findByCarrier(carrier);
	}

	@Override
	public List<Flight> flightByRoute(String source, String destiny) {
		return repo.findByRoute(source, destiny);
	}

	@Override
	public Flight flightByNo(int no) {
		return repo.findById(no).get();
	}

	@Override
	public void removeFlight(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateFlight(Flight flight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Flight> allFlights() {
		// TODO Auto-generated method stub
		return null;
	}
}
