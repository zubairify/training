package com.cg.util;

public class InvalidFlightException extends Exception {

	public InvalidFlightException() {
		super();
	}

	public InvalidFlightException(String message) {
		super(message);
	}
	
}
