package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	@Query("FROM Flight where carrier=:car")
	List<Flight> findByCarrier(@Param("car") String car);
	
	@Query("FROM Flight where source=:src and destiny=:dst")
	List<Flight> findByRoute(@Param("src") String src, @Param("dst") String dst);
}
