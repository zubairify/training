export class UserModel {
    public firstName : string;
    public lastName : string;
    public email : string;
    public mobile : number;
}
