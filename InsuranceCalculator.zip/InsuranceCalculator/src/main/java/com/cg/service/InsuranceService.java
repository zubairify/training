package com.cg.service;

import com.cg.entity.Insurance;

public interface InsuranceService {
	
	int calculateInsurance(Insurance bean);
	
	Insurance fetchInsurance(int id);
}
