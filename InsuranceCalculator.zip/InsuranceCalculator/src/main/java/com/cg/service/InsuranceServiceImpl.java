package com.cg.service;

import java.time.LocalDate;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Insurance;
import com.cg.repo.InsuranceRepo;

@Service
@Transactional
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	private InsuranceRepo repo;
	
	public int calculateInsurance(Insurance bean) {
		LocalDate today = LocalDate.now();
		int years = today.getYear() - bean.getPurchaseYear();
		
		double depreciation = years * (bean.getOnRoadPrice() * 0.5);
		double amount = (bean.getOnRoadPrice() - depreciation) * 0.25;
		bean.setInsuranceAmount(amount);
		
		LocalDate exp = today.plusYears(1);
		bean.setExpDate(new Date(exp.toEpochDay()));
		
		return repo.saveInsurance(bean);
	}
	
	public Insurance fetchInsurance(int id) {
		
		return repo.getInsurance(id);
	}

}
