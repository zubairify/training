package com.cg.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entity.Insurance;

@Repository
public class InsuranceRepoImpl implements InsuranceRepo {

	@PersistenceContext(name="SpringJPA")
	private EntityManager manager;
	
	public int saveInsurance(Insurance bean) {
		manager.persist(bean);
		return bean.getInsuranceId();
	}

	public Insurance getInsurance(int id) {
		Insurance bean = (Insurance) manager.find(Insurance.class, id);
		return bean;
	}

}
