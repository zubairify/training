package com.cg.repo;

import com.cg.entity.Insurance;

public interface InsuranceRepo {
	
	int saveInsurance(Insurance bean);
	
	Insurance getInsurance(int id);
}
