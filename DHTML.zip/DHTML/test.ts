let x:number = 10;
console.log(x);