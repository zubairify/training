package com.cg;

import org.springframework.stereotype.Component;

@Component
public class Hello {

	@Override
	public String toString() {
		return "Hello Bootiful World!";
	}
}
